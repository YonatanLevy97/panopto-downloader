chrome.webRequest.onCompleted.addListener(
    (details) => {
        if (details.url.includes("fragmented.mp4")) {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                const activeTabId = tabs[0].id;

                chrome.storage.local.get("tabFragmentLinks", (data) => {
                    const tabFragmentLinks = data.tabFragmentLinks || {};
                    const currentTabLinks = tabFragmentLinks[activeTabId] || [];

                    // Avoid duplicates
                    if (!currentTabLinks.includes(details.url)) {
                        currentTabLinks.push(details.url);
                        tabFragmentLinks[activeTabId] = currentTabLinks;

                        chrome.storage.local.set({ tabFragmentLinks });
                    }
                });
            });
        }
    },
    { urls: ["<all_urls>"] }
);


chrome.tabs.onRemoved.addListener((tabId) => {
    chrome.storage.local.get("tabFragmentLinks", (data) => {
        const tabFragmentLinks = data.tabFragmentLinks || {};
        delete tabFragmentLinks[tabId]; // Remove links for the closed tab
        chrome.storage.local.set({ tabFragmentLinks });
    });
});
